export default function DiagnosisPage() {
  const probabilities = [
    ["Leaf Spot", "100%"],
    ["Rust", "20%"],
    ["Blight", "10%"],
    ["Scab", "5%"],
  ];

  const symptoms = [
    "Spots",
    "Yellowing",
    "Wilting",
    "Powder",
    "Leaf Curl",
    "Stem Damage",
  ];

  const treatments = [
    "Use copper-based fungicide weekly",
    "Remove infected leaves immediately",
    "Avoid overhead watering",
    "Improve sunlight exposure",
    "Maintain moderate soil moisture",
  ];

  return (
    <main className="min-h-screen bg-black text-white p-4 md:p-8 overflow-x-hidden">

      {/* MAIN CONTAINER */}
      <div className="max-w-7xl mx-auto">

        {/* PAGE TITLE */}
        <h1 className="text-4xl md:text-5xl font-bold mb-2">
          Diagnosis Report
        </h1>

        <p className="text-gray-400 mb-10 text-sm md:text-base">
          AI-powered plant disease analysis and environmental insights
        </p>

        {/* GRID LAYOUT */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">

          {/* LEFT SIDE */}
          <div className="lg:col-span-2 space-y-6">

            {/* DISEASE CARD */}
            <div className="rounded-3xl border border-red-500/20 bg-red-500/5 p-6 md:p-8 backdrop-blur-sm">

              <p className="text-gray-400 text-sm mb-2">
                FINAL DIAGNOSIS
              </p>

              <h2 className="text-4xl md:text-5xl font-bold text-red-400 mb-4">
                Citrus Canker
              </h2>

              <p className="text-gray-300">
                Citrus plant diagnosed at Kolkata, India
              </p>
            </div>

            {/* PROBABILITIES */}
            <div className="rounded-3xl border border-white/10 bg-white/5 p-6 md:p-8 backdrop-blur-sm">

              <h3 className="text-2xl font-semibold mb-8">
                Symptom Probabilities
              </h3>

              {probabilities.map(([name, value]) => (
                <div key={name} className="mb-6">

                  <div className="flex justify-between mb-2 text-sm md:text-base">
                    <span>{name}</span>
                    <span>{value}</span>
                  </div>

                  <div className="w-full h-3 rounded-full bg-white/10 overflow-hidden">

                    <div
                      className="h-full bg-red-500 rounded-full transition-all duration-700"
                      style={{
                        width: value,
                      }}
                    />
                  </div>
                </div>
              ))}
            </div>

            {/* PHYSICAL SYMPTOMS */}
            <div className="rounded-3xl border border-white/10 bg-white/5 p-6 md:p-8 backdrop-blur-sm">

              <h3 className="text-2xl font-semibold mb-6">
                Mapped Physical Symptoms
              </h3>

              <div className="flex flex-wrap gap-4">

                {symptoms.map((symptom) => (
                  <div
                    key={symptom}
                    className="px-5 py-3 rounded-2xl border border-green-500/20 bg-green-500/10 text-green-300 text-sm md:text-base"
                  >
                    {symptom}
                  </div>
                ))}
              </div>
            </div>

            {/* TREATMENT */}
            <div className="rounded-3xl border border-white/10 bg-white/5 p-6 md:p-8 backdrop-blur-sm">

              <h3 className="text-2xl font-semibold mb-6">
                Treatment & Recovery
              </h3>

              <ul className="space-y-4 text-gray-300">

                {treatments.map((item) => (
                  <li key={item}>
                    • {item}
                  </li>
                ))}
              </ul>
            </div>
          </div>

          {/* RIGHT SIDE */}
          <div className="space-y-6">

            {/* WEATHER */}
            <div className="rounded-3xl border border-white/10 bg-white/5 p-6 md:p-8 backdrop-blur-sm">

              <h3 className="text-2xl font-semibold mb-8">
                Live Weather Data
              </h3>

              <div className="space-y-5">

                {[
                  ["Temperature", "28°C"],
                  ["Humidity", "57%"],
                  ["Soil Moisture", "Moderate"],
                  ["Rainfall", "0.10 mm"],
                ].map(([title, value]) => (
                  <div
                    key={title}
                    className="rounded-2xl bg-white/5 p-5 border border-white/5"
                  >
                    <p className="text-gray-400 mb-1">
                      {title}
                    </p>

                    <h4 className="text-3xl font-bold">
                      {value}
                    </h4>
                  </div>
                ))}
              </div>
            </div>

            {/* AI EXPLANATION */}
            <div className="rounded-3xl border border-white/10 bg-white/5 p-6 md:p-8 backdrop-blur-sm">

              <h3 className="text-2xl font-semibold mb-6">
                AI Diagnosis Explanation
              </h3>

              <p className="text-gray-300 leading-relaxed">
                The AI model identified visible fungal lesions,
                leaf spotting patterns, and environmental
                conditions favorable for Citrus Canker infection.
                Weather humidity and moisture levels further
                increased disease confidence.
              </p>
            </div>
          </div>
        </div>
      </div>
    </main>
  );
}