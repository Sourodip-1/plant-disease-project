"use client";

import { useRef, useState } from "react";
import { useRouter } from "next/navigation";
import { Paperclip, ArrowUp, X } from "lucide-react";

export default function Home() {
  const router = useRouter();

  const fileInputRef = useRef<HTMLInputElement>(null);

  const [selectedImage, setSelectedImage] = useState<string | null>(null);

  const [plantType, setPlantType] = useState("Rice");

  const [location, setLocation] = useState("");

  // HANDLE IMAGE UPLOAD
  const handleImageUpload = (
    event: React.ChangeEvent<HTMLInputElement>
  ) => {
    const file = event.target.files?.[0];

    if (file) {
      const imageUrl = URL.createObjectURL(file);
      setSelectedImage(imageUrl);
    }
  };

  // HANDLE ANALYZE
  const handleAnalyze = () => {
    router.push("/diagnosis");
  };

  return (
    <main className="relative min-h-screen overflow-hidden bg-black text-white flex items-center justify-center px-4 py-20">

      {/* BACKGROUND */}
      <div className="absolute inset-0 bg-black" />

      {/* RED GLOW */}
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,rgba(120,0,0,0.28),transparent_65%)]" />

      {/* DARK OVERLAY */}
      <div className="absolute inset-0 bg-black/50" />

      {/* PLUS GRID */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="grid grid-cols-[repeat(24,1fr)] h-full w-full opacity-50">

          {Array.from({ length: 480 }).map((_, i) => (
            <div
              key={i}
              className="flex items-center justify-center text-[18px] text-red-900/70"
            >
              +
            </div>
          ))}

        </div>
      </div>

      {/* NOISE TEXTURE */}
      <div className="absolute inset-0 opacity-[0.03] mix-blend-screen bg-[url('https://grainy-gradients.vercel.app/noise.svg')]" />

      {/* MAIN CONTENT */}
      <div className="relative z-10 max-w-5xl w-full flex flex-col items-center">

        {/* TITLE */}
        <h1 className="text-5xl md:text-7xl font-bold text-center leading-tight tracking-tight">
          Plant Disease
          <br />
          Diagnosis
        </h1>

        {/* SMALL TAGLINE */}
        <p className="mt-4 text-center text-red-400/80 tracking-[0.2em] uppercase text-sm">
          AI-powered crop disease detection and treatment assistance
        </p>

        {/* SUBTITLE */}
        <p className="mt-6 text-center text-gray-400 max-w-3xl text-lg md:text-xl leading-relaxed">
          Upload a plant leaf image and receive intelligent disease prediction,
          analysis and treatment suggestions instantly.
        </p>

        {/* MAIN CARD */}
        <div className="mt-16 w-full rounded-[32px] border border-white/15 bg-black/40 backdrop-blur-xl p-6 shadow-2xl">

          {/* PLANT + LOCATION */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">

            {/* PLANT TYPE */}
            <div>

              <p className="text-sm text-gray-400 mb-2">
                Plant Type
              </p>

              <select
                value={plantType}
                onChange={(e) => setPlantType(e.target.value)}
                className="w-full rounded-2xl bg-black border border-white/10 px-5 py-4 outline-none text-white"
              >

                <option className="bg-black">Rice</option>
                <option className="bg-black">Tomato</option>
                <option className="bg-black">Potato</option>
                <option className="bg-black">Apple</option>
                <option className="bg-black">Mango</option>
                <option className="bg-black">Watermelon</option>
                <option className="bg-black">Pumpkin</option>
                <option className="bg-black">Grapes</option>
                <option className="bg-black">Brinjal</option>
                <option className="bg-black">Bottle Gourd</option>
                <option className="bg-black">Bitter Gourd</option>
                <option className="bg-black">Cucumber</option>
                <option className="bg-black">Capsicum</option>
                <option className="bg-black">Corn</option>
                <option className="bg-black">Wheat</option>
                <option className="bg-black">Banana</option>
                <option className="bg-black">Papaya</option>
                <option className="bg-black">Guava</option>
                <option className="bg-black">Orange</option>
                <option className="bg-black">Lemon</option>
                <option className="bg-black">Pomegranate</option>
                <option className="bg-black">Chilli</option>
                <option className="bg-black">Onion</option>
                <option className="bg-black">Garlic</option>
                <option className="bg-black">Spinach</option>
                <option className="bg-black">Cabbage</option>
                <option className="bg-black">Cauliflower</option>
                <option className="bg-black">Tulsi</option>
                <option className="bg-black">Aloe Vera</option>
                <option className="bg-black">Hibiscus</option>
                <option className="bg-black">Rose</option>
                <option className="bg-black">Sunflower</option>
                <option className="bg-black">Sugarcane</option>
                <option className="bg-black">Cotton</option>
                <option className="bg-black">Soybean</option>

              </select>
            </div>

            {/* LOCATION */}
            <div>

              <p className="text-sm text-gray-400 mb-2">
                Location
              </p>

              <input
                type="text"
                placeholder="Enter location..."
                value={location}
                onChange={(e) => setLocation(e.target.value)}
                className="w-full rounded-2xl bg-black border border-white/10 px-5 py-4 outline-none text-white placeholder:text-gray-500"
              />

            </div>
          </div>

          {/* IMAGE PREVIEW */}
          {selectedImage && (
            <div className="mb-8 relative w-fit">

              <img
                src={selectedImage}
                alt="Uploaded"
                className="w-48 h-48 object-cover rounded-2xl border border-white/10"
              />

              {/* REMOVE BUTTON */}
              <button
                onClick={() => setSelectedImage(null)}
                className="absolute -top-2 -right-2 bg-red-600 hover:bg-red-700 rounded-full p-1"
              >
                <X size={16} />
              </button>

            </div>
          )}

          {/* UPLOAD AREA */}
          <div className="border border-dashed border-white/10 rounded-3xl p-16 flex flex-col items-center justify-center text-center">

            {/* HIDDEN INPUT */}
            <input
              type="file"
              accept="image/*"
              ref={fileInputRef}
              onChange={handleImageUpload}
              className="hidden"
            />

            {/* UPLOAD BUTTON */}
            <button
              onClick={() => fileInputRef.current?.click()}
              className="h-16 w-16 rounded-full bg-white/5 hover:bg-white/10 border border-white/10 flex items-center justify-center transition duration-300 mb-4"
            >
              <Paperclip size={30} />
            </button>

            <p className="text-gray-300 text-lg">
              Upload a plant leaf image
            </p>

            <p className="text-gray-500 text-sm mt-2">
              JPG, PNG supported
            </p>

          </div>

          {/* ANALYZE BUTTON */}
          <div className="mt-8 flex justify-end">

            <button
              onClick={handleAnalyze}
              className="h-16 w-16 rounded-full bg-white/10 hover:bg-white/20 border border-white/10 flex items-center justify-center transition duration-300"
            >
              <ArrowUp size={32} />
            </button>

          </div>
        </div>
      </div>
    </main>
  );
}